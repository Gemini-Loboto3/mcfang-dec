#include <types.h>

u32 Compress(u8* &out, u8* in, u32 src_size);
u32 Decompress(u8 *data, u8 *&dest);